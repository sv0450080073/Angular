﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reprocess.Common
{
   public  enum Flow
    {
        CIP = 1,
        EDIExtract = 2
    }
}
